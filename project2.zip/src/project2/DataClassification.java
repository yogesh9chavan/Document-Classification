package project2;

import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.stream.Stream;

public class DataClassification {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	File datafile1;
	File datafile2;
	Map<Integer, List<String>> documentCollection1 = new HashMap<Integer, List<String>>();
	Map<Integer, List<String>> documentCollection2 = new HashMap<Integer, List<String>>();
	List<String> countedWords = new ArrayList();
	Map<String, Integer> difMap = new HashMap<String, Integer>();
	Map<String, Double> tfMusicMap = new HashMap<String, Double>();
	Map<String, Double> tfSportsMap = new HashMap<String, Double>();
	Map<String, Double> tfdifMusicMap = new HashMap<String, Double>();
	Map<String, Double> tfdifSportsMap = new HashMap<String, Double>();
	DecimalFormat df = new DecimalFormat("0.0");
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DataClassification window = new DataClassification();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static <K, V extends Comparable<? super V>> Map<K, V> 
    sortByValue( Map<K, V> map )
    {
      Map<K,V> result = new LinkedHashMap<>();
      Stream <Entry<K,V>> st = map.entrySet().stream();

      st.sorted(Comparator.comparing(e -> e.getValue()))
          .forEach(e ->result.put(e.getKey(),e.getValue()));

      return result;
    }
	/**
	 * Create the application.
	 */
	public DataClassification() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 459, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSelectFile = new JLabel("Select File 1");
		lblSelectFile.setBounds(10, 40, 73, 14);
		frame.getContentPane().add(lblSelectFile);
		
		textField = new JTextField();
		textField.setBounds(93, 37, 214, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnBrowse = new JButton("Browse");
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
	            chooser.setCurrentDirectory(new java.io.File("."));
	            chooser.setDialogTitle("Select the file");
	            chooser.setFileSelectionMode(JFileChooser.OPEN_DIALOG);
	            chooser.showOpenDialog(null);
	            datafile1 = chooser.getSelectedFile();
	            if(datafile1 != null)
	            {
	            	textField.setText(datafile1.getAbsolutePath());
	            	textField.setEnabled(false);
	            }
			}
		});
		btnBrowse.setBounds(324, 36, 100, 23);
		frame.getContentPane().add(btnBrowse);
		
		JLabel lblSelectFile_1 = new JLabel("Select File 2");
		lblSelectFile_1.setBounds(10, 84, 73, 14);
		frame.getContentPane().add(lblSelectFile_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(93, 81, 214, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnBrowse_1 = new JButton("Browse");
		btnBrowse_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
	            chooser.setCurrentDirectory(new java.io.File("."));
	            chooser.setDialogTitle("Select the file");
	            chooser.setFileSelectionMode(JFileChooser.OPEN_DIALOG);
	            chooser.showOpenDialog(null);
	            datafile2 = chooser.getSelectedFile();
	            if(datafile2 != null)
	            {
	            	textField_1.setText(datafile2.getAbsolutePath());
	            	textField_1.setEnabled(false);
	            }
			}
		});
		btnBrowse_1.setBounds(324, 80, 100, 23);
		frame.getContentPane().add(btnBrowse_1);
		
		JButton btnConstructFeature = new JButton("Construct Feature");
		btnConstructFeature.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(datafile1 == null)
				{
					JOptionPane.showMessageDialog(null,"Select files first", "Message", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				if(datafile2 == null)
				{
					JOptionPane.showMessageDialog(null,"Select files first", "Message", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				documentCollection1 = GetDocumentCollection(datafile1);
				documentCollection2 = GetDocumentCollection(datafile2);
				
				try {
					TFFeatureConstruction("Class1MusicFV-TF.txt","Class1MusicFV-TFIDF.txt",tfMusicMap, tfdifMusicMap, documentCollection1);
					TFFeatureConstruction("Class2SportsFV-TF.txt","Class2SportsFV-TFIDF.txt",  tfSportsMap, tfdifSportsMap, documentCollection2);
					JOptionPane.showMessageDialog(null,"Feature construction completed", "Message", JOptionPane.INFORMATION_MESSAGE);
					//TempMethod();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnConstructFeature.setBounds(10, 177, 158, 23);
		frame.getContentPane().add(btnConstructFeature);
		
		JButton btnNewButton = new JButton("Feature Selection");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(tfMusicMap.size() < 1 || tfSportsMap.size() < 1)
				{
					JOptionPane.showMessageDialog(null,"Please construct feature first", "Message", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				
				if(tfdifMusicMap.size() < 1 || tfdifSportsMap.size() < 1)
				{
					JOptionPane.showMessageDialog(null,"Please construct feature first", "Message", JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				
				String inputNumberOfFeatures = (String)JOptionPane.showInputDialog(
	                    new Frame(),
	                    "Enter number of features",
	                    "User input",
	                    JOptionPane.PLAIN_MESSAGE,
	                    null,
	                    null, null);
				
				if(inputNumberOfFeatures == "")
					return;
				int count=0;
				List<String> topKMusicFeatures = new ArrayList<String>();
				List<String> topKSportsFeatures = new ArrayList<String>();
				Map<String, Double> sortedTfMusicMap = sortByValue(tfMusicMap);
				Map<String, Double> sortedTfSportsMap = sortByValue(tfSportsMap);
				//System.out.println(tfMusicMap);
				//System.out.println(sortedTfMusicMap);
				//System.out.println("------------------");
				//System.out.println(sortedTfSportsMap);
				//System.out.println("------------------");
				Object[] tfMusicKeys = sortedTfMusicMap.keySet().toArray();
				Object[] tfSportsKeys = sortedTfSportsMap.keySet().toArray();
				for(int i=sortedTfMusicMap.size()-1;i>=0;i--)
				{
					String word = tfMusicKeys[i].toString();
					double tfMusicCount = sortedTfMusicMap.get(word);
					if(sortedTfSportsMap.get(word) != null)
					{
						double tfSportsCount = sortedTfSportsMap.get(word);
						if(tfMusicCount>tfSportsCount)
							topKMusicFeatures.add(word+"="+tfMusicCount);
					}
					else
						topKMusicFeatures.add(word+"="+tfMusicCount);
				}
				
				for(int i=sortedTfSportsMap.size()-1;i>=0;i--)
				{
					String word = tfSportsKeys[i].toString();
					double tfSportsCount = sortedTfSportsMap.get(word);
					if(sortedTfMusicMap.get(word) != null)
					{
						double tfMusicCount = sortedTfMusicMap.get(word);
						if(tfMusicCount<tfSportsCount)
							topKSportsFeatures.add(word+"="+tfSportsCount);
					}
					else
						topKSportsFeatures.add(word+"="+tfSportsCount);
				}
				
				try {
					//System.out.println(topKMusicFeatures);
					//System.out.println("------------------");
					//System.out.println(topKSportsFeatures);
					PrintWriter pw = new PrintWriter("Class1MusicFV-TF-"+inputNumberOfFeatures+".txt", "UTF-8");
					for(int i=0; i<Integer.parseInt(inputNumberOfFeatures) && i<topKMusicFeatures.size();i++)
						pw.println(topKMusicFeatures.get(i));
					pw.close();
					PrintWriter pw1 = new PrintWriter("Class1SportsFV-TF-"+inputNumberOfFeatures+".txt", "UTF-8");
					for(int i=0; i<Integer.parseInt(inputNumberOfFeatures) && i<topKSportsFeatures.size();i++)
						pw1.println(topKSportsFeatures.get(i));
					pw1.close();
				} catch (FileNotFoundException | UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				List<String> topKdifMusicFeatures = new ArrayList<String>();
				List<String> topKdifSportsFeatures = new ArrayList<String>();
				Map<String, Double> sortedTfdifMusicMap = sortByValue(tfdifMusicMap);
				Map<String, Double> sortedTfdifSportsMap = sortByValue(tfdifSportsMap);
				//System.out.println(tfMusicMap);
				//System.out.println(sortedTfMusicMap);
				//System.out.println("------------------");
				//System.out.println(sortedTfSportsMap);
				//System.out.println("------------------");
				Object[] tfdifMusicKeys = sortedTfdifMusicMap.keySet().toArray();
				Object[] tfdifSportsKeys = sortedTfdifSportsMap.keySet().toArray();
				for(int i=sortedTfdifMusicMap.size()-1;i>=0;i--)
				{
					String word = tfdifMusicKeys[i].toString();
					double tfdifMusicCount = sortedTfdifMusicMap.get(word);
					if(sortedTfdifSportsMap.get(word) != null)
					{
						double tfdifSportsCount = sortedTfdifSportsMap.get(word);
						if(tfdifMusicCount>tfdifSportsCount)
							topKdifMusicFeatures.add(word+"="+tfdifMusicCount);
					}
					else
						topKdifMusicFeatures.add(word+"="+tfdifMusicCount);
				}
				
				for(int i=sortedTfdifSportsMap.size()-1;i>=0;i--)
				{
					String word = tfdifSportsKeys[i].toString();
					double tfdifSportsCount = sortedTfdifSportsMap.get(word);
					if(sortedTfdifMusicMap.get(word) != null)
					{
						double tfdifMusicCount = sortedTfdifMusicMap.get(word);
						if(tfdifMusicCount<tfdifSportsCount)
							topKdifSportsFeatures.add(word+"="+tfdifSportsCount);
					}
					else
						topKdifSportsFeatures.add(word+"="+tfdifSportsCount);
				}
				
				try {
					//System.out.println(topKMusicFeatures);
					//System.out.println("------------------");
					//System.out.println(topKSportsFeatures);
					PrintWriter pw = new PrintWriter("Class1MusicFV-TFIDF-"+inputNumberOfFeatures+".txt", "UTF-8");
					for(int i=0; i<Integer.parseInt(inputNumberOfFeatures) && i<topKdifMusicFeatures.size();i++)
						pw.println(topKdifMusicFeatures.get(i));
					pw.close();
					PrintWriter pw1 = new PrintWriter("Class1SportsFV-TFIDF-"+inputNumberOfFeatures+".txt", "UTF-8");
					for(int i=0; i<Integer.parseInt(inputNumberOfFeatures) && i<topKdifSportsFeatures.size();i++)
						pw1.println(topKdifSportsFeatures.get(i));
					pw1.close();
				} catch (FileNotFoundException | UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(178, 177, 141, 23);
		frame.getContentPane().add(btnNewButton);
	}
	
	public Map<Integer, List<String>> GetDocumentCollection(File datafile)
	{
		Map<Integer, List<String>> documentCollection = new HashMap<Integer, List<String>>();
		
		int documentCount = 1;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader((String)datafile.getAbsolutePath()));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String line = null;
		//recordList.clear();
		try {
			while((line = reader.readLine()) != null)
			{
				List<String> documentWords = new ArrayList<String>();
				if(line != null && !line.isEmpty())
				{
					documentWords.clear();
					String[] values = line.split(" ");
					for(String word : values)
						documentWords.add(word);
					documentCollection.put(documentCount, documentWords);
					documentCount++;
				}
			}
			reader.close();
			//System.out.println(documentCollection);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return documentCollection;
	}
	
		
	public void TFFeatureConstruction(String f1fileName, String f2fileName, Map<String, Double> tfMap, Map<String, Double> tfdifMap, Map<Integer, List<String>> documentCollection) throws IOException, Exception
	{
		if(documentCollection == null || documentCollection.size() < 1)
		{
			JOptionPane.showMessageDialog(null,"Select files first", "Message", JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		//JOptionPane.showMessageDialog(null,"Please wait for some time as it constructs features ", "Message", JOptionPane.INFORMATION_MESSAGE);
		PrintWriter pw = new PrintWriter(f1fileName, "UTF-8");
		pw.println("Words and respective frequency:");
		List<Integer> counts = new ArrayList<Integer>();
		
		for(int i=1; i<=documentCollection.size(); i++)
		{
			Map<String, Integer> wordCount = new HashMap<String, Integer>();
			List<String> documentwords = documentCollection.get(i);
			for(int j=0; j<documentwords.size();j++)
			{
				
				int count = 0;
				for(int k=0; k<documentwords.size();k++)
				{
					if(documentwords.get(j).equals(documentwords.get(k)))
							count++;		
				}
				if(!countedWords.contains(documentwords.get(j)))
					countedWords.add(documentwords.get(j));
				wordCount.put(documentwords.get(j), count);
				counts.add(count);
			}
			Collections.sort(counts);
			double maxCount = counts.get(counts.size()-1);
			pw.println();
			pw.println("D"+i);
			Object[] keys = wordCount.keySet().toArray();
			for(int w=0;w<wordCount.size();w++)
			{
				double count = wordCount.get(keys[w]);
				pw.print(keys[w]+"="+(df.format(count/maxCount))+ " ");
				tfMap.put(keys[w].toString(), Double.parseDouble(df.format(count/maxCount)));
			}
			pw.println();
			pw.println("Transformed data :");
			pw.println();
			for(int w=0;w<wordCount.size();w++)
			{
				double count = wordCount.get(keys[w]);
				pw.print(df.format(count/maxCount)+ " ");
			}
			pw.println();
		}
		pw.close();
		for(int i=0; i<countedWords.size();i++)
		{
			int count = 0;
			for(int j=1;j<documentCollection.size();j++)
			{
				List<String> documentwords = documentCollection.get(j);
				for(int k=0; k<documentwords.size();k++)
				{
					if(countedWords.get(i).equals(documentwords.get(k)))
					{
						count++;
						break;
					}
				}
			}
			difMap.put(countedWords.get(i), count);
			
		}
		//System.out.println(difMap);
		PrintWriter pw1 = new PrintWriter(f2fileName, "UTF-8");
		Object[] keysdif = difMap.keySet().toArray();
		for(int j=1; j<difMap.size();j++)
		{
			int wordFreq = difMap.get(keysdif[j]);
			if(wordFreq != 0)
			{
				double inverseDocFreq = Math.log(documentCollection.size()/wordFreq)/Math.log(2);
				double termFreq = tfMap.get(keysdif[j]);
				pw1.print(keysdif[j]+ "=" + termFreq*inverseDocFreq+ " ");
				tfdifMap.put(keysdif[j].toString(), termFreq*inverseDocFreq);
			}
		}
		pw1.close();
	}
}
