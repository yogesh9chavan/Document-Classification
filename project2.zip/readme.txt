-To open the code and run the application, follow the below steps:

1. Open Eclipse
2. Click on File menu and then Open file menu option
3. Open DataClassification.java file
4. Run the program


-To run the application directly double click on Project2.exe

-Report is present in "Project2_Report_Yogesh_Chavan.doc"

-Input files are in "input files" folder

-Output files are in "output files" folder

-Input file for Weka is "input.arff"

-Output files of Weka are in "output files of Weka" folder 

-All output files are generated in the program running environment.



